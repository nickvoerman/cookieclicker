//money
let money = 1000;
let moneyshower = document.querySelector('.js-money-shower');
//money per second
let moneyPerSecond = 0;
let moneyshowerPerSecond = document.querySelector('.js-money-per-second');
//cookie
const cookie = document.querySelector('.cookie');
//buildings
const showbuildings = document.querySelector('.js-show-buildings');
const buildings = document.querySelector('.js-buildings');
//factory
const factorydiv = document.querySelector('.js-factory-div');
const factorybuy = document.querySelector('.js-factory-buy');
const factorybuyworkers = document.querySelector('.js-factory-buyworkers');
const factory = document.querySelector('.js-factory');
let factoryowned = false;
let factoryworkersmax = 0;
let factorylevel = 0;
let factoryprice = 25;
let workerasecond = 0.1;
let workers = 0;

function notification(message) {
    Toastify({
        text: message,
        duration: 2000,
        close: true,
        gravity: "top", // `top` or `bottom`
        position: 'right', // `left`, `center` or `right`
        backgroundColor: "red",
        className: 'notification',
        stopOnFocus: true, // Prevents dismissing of toast on hover
        onClick: function () { } // Callback after click
    }).showToast();
}

function CreateFactory(purchaseAmount) {
    this.purchaseAmount = purchaseAmount;
    if (money >= this.purchaseAmount) {
        factorylevel++;
        factoryworkersmax = factoryworkersmax + 15;
        factory.innerHTML = '🏭 Level : ' + factorylevel + ' | workers : ' + workers + ' / ' + factoryworkersmax;
        money -= this.purchaseAmount

       

        const style = getStyle('.js-factory', 'display');
        if (style === 'none') {
            factory.style.display = 'block';
            factorybuy.innerHTML = 'level up';
            factorybuyworkers.style.display = 'inline-block';

        }

    }
    else {
        notification('You dont have enough money');
    }
}

factorybuy.addEventListener('click', () => {

    if(factorylevel == 0) {
        CreateFactory(factoryprice, 0.1);
    } 
    else if (workers >= factoryworkersmax) {
        CreateFactory(factoryprice, 0.1);     
    } else {
        notification('You dont have max workers yet');
    }
});

factorybuyworkers.addEventListener('click', () => {
    if(factorylevel === factorylevel) {
        if (workers !== factoryworkersmax)
        {
            workers++;
            factory.innerHTML = '🏭 Level : ' + factorylevel + ' | workers : ' + workers + ' / ' + factoryworkersmax;
            moneyPerSecond = moneyPerSecond + workerasecond;
        }
        else {
        notification('You have max workers');       
        }
    }
});

cookie.addEventListener('click', () => {
    money++;
    moneyshower.innerHTML = '🍪 : ' + money.toFixed(1);
});

showbuildings.addEventListener('click', () => {
    const style = getStyle('.js-buildings', 'display');
    if (style === 'none') {
        showbuildings.innerHTML = 'hide buildings';
        buildings.style.display = 'block';
    }
    else {
        showbuildings.innerHTML = 'show buildings';
        buildings.style.display = 'none';
    }

});

setInterval(() => {
    money = money + moneyPerSecond;
    moneyshower.innerHTML = '🍪 : ' + money.toFixed(1);
    moneyshowerPerSecond.innerHTML = '🍪 per second : ' + moneyPerSecond.toFixed(1);
    console.log(factoryworkersmax);
}, 1000);



function getStyle(el, name) {
    const element = document.querySelector(el);
    return element.currentStyle ? element.currentStyle[name] : window.getComputedStyle ? window.getComputedStyle(element, null).getPropertyValue(name) : null;
}

// make array for worker a sec and factory price just simple do it with factory level