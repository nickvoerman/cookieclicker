//money
let money = 0;
let moneyshower = document.querySelector('.js-money-shower');
//money per second
let moneyPerSecond = 0;
let moneyshowerPerSecond = document.querySelector('.js-money-per-second');

//cookie
const cookie = document.querySelector('.cookie');
//buildings
const factory = document.querySelector('.js-factory-buy');
function CreateFactory(purchaseAmount, moneyASec) {
    console.log('wut');
    this.purchaseAmount = purchaseAmount;
    console.log(this.purchaseAmount);
    if(money >= this.purchaseAmount) {
        console.log('hi');
        money -= this.purchaseAmount
        moneyPerSecond = moneyPerSecond + moneyASec;
        console.log(moneyPerSecond);
    } 
    else 
    { 
        console.log('not enough money'); 
    }
   
  }
factory.addEventListener('click',() => {
    console.log('user wants to buy factory');
    CreateFactory(10, 0.1);
});
cookie.addEventListener('click',() => {
    money++;
    moneyshower.innerHTML = 'Cookies: ' + money.toFixed(1);
});

setInterval(() => {
    console.log('money per second:', moneyPerSecond);
    money = money + moneyPerSecond;
    moneyshower.innerHTML = 'Cookies: ' + money.toFixed(1);
    moneyshowerPerSecond.innerHTML = 'per second : ' + moneyPerSecond.toFixed(1);
    console.log(money);
}, 1000);