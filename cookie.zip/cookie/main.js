//money
let money = 0;
let moneyshower = document.querySelector('.js-money-shower');
//money per second
let moneyPerSecond = 0;
let moneyshowerPerSecond = document.querySelector('.js-money-per-second');
//cookie
const cookie = document.querySelector('.cookie');
//buildings
const factory = document.querySelector('.js-factory-buy');
const factoryowned = document.querySelector('.js-factorys-owned');
let factoryownednumber = 0;

function notificationCSS(message) {
    new NotifyJS(
        {
            duration: 2000,
            message: message,
        },
        {
            textColor: 'white',
            customCSSBox: `font-weight: bold;background-color: black;`
        }
    )
}

function CreateFactory(purchaseAmount, moneyASec) {
    this.purchaseAmount = purchaseAmount;
    console.log(this.purchaseAmount);
    if(money >= this.purchaseAmount) {
        factoryownednumber++;
        factoryowned.innerHTML = '🏭 owned : ' + factoryownednumber;
        money -= this.purchaseAmount
        moneyPerSecond = moneyPerSecond + moneyASec;
        console.log(moneyPerSecond);
    } 
    else 
    { 
        console.log('not enough money'); 
        notificationCSS('You dont have enough money');
    }
  }
  
factory.addEventListener('click',() => {
    console.log('user wants to buy factory');
    CreateFactory(10, 0.1);
});
cookie.addEventListener('click',() => {
    money++;
    moneyshower.innerHTML = '🍪 : ' + money.toFixed(1);
});

setInterval(() => {
    money = money + moneyPerSecond;
    moneyshower.innerHTML = '🍪 : ' + money.toFixed(1);
    moneyshowerPerSecond.innerHTML = '🍪 per second : ' + moneyPerSecond.toFixed(1);
}, 1000);